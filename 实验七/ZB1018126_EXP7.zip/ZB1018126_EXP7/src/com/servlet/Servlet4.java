package com.servlet;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.Connect;

/**
 * Servlet implementation class Servlet4
 */
@WebServlet("/Servlet4")
public class Servlet4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection connection;
	ResultSet res;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = null,password=null;
		username = new String(request.getParameter("username").getBytes("ISO-8859-1"), "UTF-8");
		password = new String(request.getParameter("password").getBytes("ISO-8859-1"), "UTF-8");
		
		HttpSession session = request.getSession();
		Connect con=new Connect();
		
		connection=con.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement("select * from user where name='"+username+"' and password='"+password+"';");
			res=ps.executeQuery();
			if(res.next()){
				response.sendRedirect(request.getContextPath()+ "/welcome.jsp");
			}else{
				response.sendRedirect(request.getContextPath()+ "/error.jsp");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
	}

}
