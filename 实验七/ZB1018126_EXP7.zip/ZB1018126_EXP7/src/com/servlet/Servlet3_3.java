package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Triangle;

/**
 * Servlet implementation class Servlet3_3
 */
@WebServlet("/Servlet3_3")
public class Servlet3_3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet3_3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		if(request.getParameter("num1").equals("")||request.getParameter("num2").equals("")||request.getParameter("num3").equals("")) {
			session.setAttribute("error", "�����߲���Ϊ��");
			response.sendRedirect(request.getContextPath() + "/input3_1.jsp");
			return;
		}
		String one=request.getParameter("num1");
		String two=request.getParameter("num2");
		String three=request.getParameter("num3");
		double num1 = 0,num2 = 0,num3 = 0;
		try {
			num1=Double.parseDouble(one);
			num2=Double.parseDouble(two);
			num3=Double.parseDouble(three);
		}catch(NumberFormatException e){
			session.setAttribute("erro", "�����߲���Ϊ��");
			response.sendRedirect(request.getContextPath()+"/input3_1");
		}
		if(num1<=0||num2<=0||num3<=0){
			session.setAttribute("error", "�����߲���С��0");
			response.sendRedirect(request.getContextPath() + "/input3_1.jsp");
			return;
		}
		
		
		Triangle tri=new Triangle();
		boolean isTriangle;
		isTriangle=tri.isTriangle(num1, num2, num3);
		if(!isTriangle) {
			session.setAttribute("error", "����������");
			response.sendRedirect(request.getContextPath() + "/input3_1.jsp");
			return;
		}
		String str=tri.equalTriangle(num1, num2, num3);
		double sum=tri.computerTriangle(num1, num2, num3);
		session.setAttribute("sum", sum);
		session.setAttribute("str", str);
		response.sendRedirect(request.getContextPath()+"/show3_2.jsp");
		
		
	}

	private void println(String string) {
		// TODO Auto-generated method stub
		
	}

}
