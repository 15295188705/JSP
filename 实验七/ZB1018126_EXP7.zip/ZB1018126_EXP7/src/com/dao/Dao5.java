package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.alibaba.druid.pool.DruidPooledConnection;
import com.bean.User;
import com.util.DbConnection;

public class Dao5 {
	ResultSet res;
	public User selectUser(User user) {
		User resultUser = null;
		
		DbConnection dbp = DbConnection.getInstance();
        DruidPooledConnection con = null;
        PreparedStatement ps = null;
        //�������ݳ�
		try {
			con = dbp.getConnection();
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
        
        //�������ݿ�
        try{ 
            ps = con.prepareStatement("select * from user where name='"+user.getName()+"' and password='"+user.getPassword()+"';");
            res=ps.executeQuery();
            if(res.next()){
            	resultUser=new User();
            	resultUser.setName(res.getString("name"));
            	resultUser.setPassword(res.getString("password"));
            }
			
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
             
		return resultUser;
	}
}
