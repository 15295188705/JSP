package com.dao;

public class Triangle {
	
	public boolean isTriangle(double num1,double num2,double num3) {
		if ((num1+num2)<=num3||(num1+num3)<=num2||(num2+num3)<=num1){
			return false;
		}else
			return true;
	}
	
	public double computerTriangle(double num1, double num2, double num3) {
		double sum = 0;
		double p = (num1 + num2 + num3) / 2;
		sum = Math.sqrt(p*(p-num1)*(p-num2)*(p-num3));
		return sum;
	}
	public String equalTriangle(double num1, double num2, double num3) {
		if(num1==num2&&num2==num3){
			return "����������";
		}else
			return "���ǵ���������";
	}
}
