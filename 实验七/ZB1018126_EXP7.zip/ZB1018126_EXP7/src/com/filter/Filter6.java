package com.filter;

import com.alibaba.druid.filter.FilterChain;

import java.io.IOException;

import javax.servlet.annotation.WebFilter;




/**
 * Servlet Filter implementation class Filter
 */
@WebFilter("/Filter6")
public class Filter6 implements javax.servlet.Filter {

    /**
     * Default constructor. 
     */
    public Filter6() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter6#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter6#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String name=request.getParameter("username");
 
   
        if (name!=null&&name.startsWith("T"))
        {
        	request.getRequestDispatcher("error.jsp").forward(request, response);
        }else{
        	request.getRequestDispatcher("welcome.jsp").forward(request, response);
        }
 
       
	}

	/**
	 * @see Filter6#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
