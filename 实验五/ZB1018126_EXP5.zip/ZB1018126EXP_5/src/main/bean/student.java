package bean;

public class student {
    private int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public student(int age) {
        this.age = age;
    }

    public student() {
    }
}
